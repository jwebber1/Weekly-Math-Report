/*
    Author: Jonathan Webber
    Date:   3/19/2018
    Description:
        This program works specifically with the math report generated weekly
    at the Center for Academic Support at Missouri Western. It launches, takes
    in a .txt file, re-formats the data, and then creates a new .txt file ready
    to copy and paste to Math Department teachers.
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.io.*;

public class WeeklyMathReport extends Application{



    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Weekly Math Report");


        //creating layout of Scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10,10,10,10));
        layout.setHgap(5);
        layout.setVgap(20);

        //top left label for no .txt
        Label txtLabel = new Label("Do not include \".txt\" in the file names below");
        GridPane.setConstraints(txtLabel,0,0);
        GridPane.setColumnSpan(txtLabel,2);
        layout.getChildren().add(txtLabel);

        //next row label
        Label inputLabel = new Label("File you would like to format: ");
        GridPane.setConstraints(inputLabel,0,1);
        layout.getChildren().add(inputLabel);

        //next column textfield
        TextField inputText = new TextField();
        inputText.setPromptText("input file name");
        inputText.setPrefColumnCount(10);
        inputText.getText();
        GridPane.setConstraints(inputText,1,1);
        layout.getChildren().add(inputText);

        //next row label
        Label outputLabel = new Label("Name of your reformatted file: ");
        GridPane.setConstraints(outputLabel,0,2);
        layout.getChildren().add(outputLabel);

        //next column textfield
        TextField outputText = new TextField();
        outputText.setPromptText("output file name");
        outputText.setPrefColumnCount(10);
        outputText.getText();
        GridPane.setConstraints(outputText,1,2);
        layout.getChildren().add(outputText);

        //empty label area for finished text
        Label eventLabel = new Label();
        GridPane.setConstraints(eventLabel,0,3);
        GridPane.setColumnSpan(eventLabel,2);
        layout.getChildren().add(eventLabel);

        //Lastly, a button in the top right
        Button reformat = new Button("Submit");
        GridPane.setConstraints(reformat,1,0);
        GridPane.setHalignment(reformat, HPos.RIGHT);
        layout.getChildren().add(reformat);

        reformat.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if((inputText.getText() != null && !inputText.getText().isEmpty())&&
                        (outputText.getText() != null && !outputText.getText().isEmpty())){

                    try {
                        doSummary(inputText.getText(),outputText.getText());
                        eventLabel.setText("File "+inputText.getText()+".txt successfully formatted and named "+outputText.getText()+".txt.");

                    } catch (IOException e) {
                        eventLabel.setText("Error: Could not find file "+inputText.getText()+".txt.");
                    }
                }
                else {
                    eventLabel.setText("Please put file names into the text boxes above.");

                }
            }
        });



        Scene mainScene = new Scene(layout, 500, 175);
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }

    public void doSummary(String inName, String outName) throws IOException {
        PrintWriter outpt; //create the printwriter object

            //now equate the internal name to an external file through the printwriter
            outpt= new PrintWriter(new File(outName+".txt")); //create path to output file
            //will hold lineJustFetched after it has been split "\t"
            String[] wordsArray;

            //create a buffer reader to read each line
            BufferedReader buffer = new BufferedReader(new FileReader(inName+".txt"));

            //will temporarily holds line being looked at
            String lineJustFetched = buffer.readLine();

            //while loop splitting line fed on "\t", storing into wordsArray, and
            //then putting into a new Student object and lastly the students ArrayList
            while(lineJustFetched != null){
                wordsArray = lineJustFetched.split("\t");

                if(wordsArray.length == 1){
                    outpt.print(wordsArray[0]);
                }
                else if(wordsArray.length == 2){

                }
                else if(wordsArray.length == 3){
                    for(int i = 0; i<wordsArray.length; i++){
                        if(i==0)outpt.print("\t"+wordsArray[i+1]+"\t");
                        else if(i==1)outpt.print(wordsArray[i-1]+"\t");
                    }

                    //outpt.println();
                }
                else {
                    for(int i = 0; i<wordsArray.length; i++){
                        if(i==0)outpt.print("\t\t"+wordsArray[i]+"\t");
                        else if(i==1)outpt.print(wordsArray[i]+" - ");
                        else if(i==2)outpt.print(wordsArray[i]+"\t");
                        else if(i==3)outpt.print(wordsArray[i]+" min");

                    }

                }
                outpt.println();

                //move to next line in .txt file
                lineJustFetched = buffer.readLine();
            }//close while loop

            //close the buffer
            buffer.close();
            outpt.close();

    }
}
